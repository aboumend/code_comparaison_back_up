import tensorflow as tf
import numpy as np

class Pruner:
    def __init__(self, arch, data, density):
        self.arch=arch #architecture a elaguer
        self.data=data #si la methode d'elagage necessite l'acces au donnees elles sont contenu dans cet attribut
        self.density=density

    def create_masks(self): 
        #methode qui retourne un dictionnaire associant un mask a chaque matrice de poids (une matrice de poids par layer)
        #on utilise un dictionnaire pour avoir les cle
        #les cles sont l'attribut name du layer
        masks={} #dictionnaire
        for i in range(len(self.arch.layers)):
            name=getattr(self.arch.layers[i], 'name')
            masks[name]=tf.zeros(self.arch.layers[i].get_weights()[0].shape ,dtype=tf.dtypes.float32)
        return masks
    
    def apply_masks(self,masks):
        #IMPORTANT: le mask doit etre un tensorflow tensor (tf.constant(np.array) les elements en float mettre 1. ou 0.) de type float32
        #masks est un dictionnaire qui associe à chaque matrice de poids du layer son masque
        #la clé du dictionnaire masks est l'attribut name du layer
        #multiplie les poids par les masques pour mettre les poids elagues a zero
        for i in range(len(self.arch.layers)):
            name=getattr(self.arch.layers[i], 'name')
            mask=masks[name]
            #print("mask", mask)
            weights=self.arch.layers[i].get_weights()
            #print("weights before pruning", self.arch.layers[i].get_weights())
            new_weights=tf.math.multiply(weights,mask)
            new_weights=tf.convert_to_tensor(new_weights)
            self.arch.layers[i].set_weights(new_weights)
            #print("weight after pruning", self.arch.layers[i].get_weights())
            #print("----------------------------------------------------------------------")
    
    def compute_pruning_masks(self):
        raise NotImplementedError()

class MagnetitudePruner(Pruner):
    def __init__(self, arch, data, density):
        super().__init__(arch,data,density)

    def compute_pruning_masks(self):
        print("computing pruning masks according the global magnetitude pruning algorithm")
        weight_abs= []
        for i in range(len(self.arch.layers)):
            weights=self.arch.layers[i].get_weights()[0]
            for shape0 in range(weights.shape[0]):
                for shape1 in range(weights.shape[1]):
                    weight_abs.append(abs(weights[shape0][shape1]))
            
        #print(weight_abs)
        num_params_to_keep = int(len(weight_abs) * self.density)
        if (num_params_to_keep==0):
            print("all parameters are removed with this sparsity level")
            return num_params_to_keep, None
        if (num_params_to_keep==len(weight_abs)):
            print("all parameters are kept, keeping the same network")
            return num_params_to_keep, None
        
        #print("nb poids a garder", num_params_to_keep)
        #on recupere les k plus grand elements de weight_abs en ordonnant avec sorted (du plus petit au plus grand)
        #puis on recupere les k dernier element de sorted(weight_abs) parce que ca donne les k plus grand
        #le k c'est le num_params_to_keep
        sorted_weight_abs=sorted(weight_abs)
        #print("poids ordonnees", sorted_weight_abs)
        topk_weights=sorted_weight_abs[-num_params_to_keep:]
        #print("plus grand poids",topk_weights)
        #le plus petit poids parmi les k plus grand est le seuil en dessous duquel on elague (tous les param<seuil sont elagues)
        threshold=topk_weights[0]
        #print("threshold", threshold)
        masks=self.create_masks()
        #print("masks created", masks)
        #on calcule les masques d'élegage
        for i in range(len(self.arch.layers)):
            name=getattr(self.arch.layers[i], 'name')
            weights=self.arch.layers[i].get_weights()[0]
            #print("weights", weights)
            mask=(tf.math.abs(weights)>=threshold) #le masque=1 pour les poids>threshold 0 sinon
            masks[name]=tf.cast(mask, float)
            #print("mask", masks[name])
        return num_params_to_keep, masks


class RandomERPruner(Pruner):
    def __init__(self, arch, data, density, erk_power_scale=1.0):
        super().__init__(arch,data,density)
        self.erk_power_scale=erk_power_scale
        
    def compute_pruning_masks(self):
        masks=self.create_masks()
        #print("masks", masks)
        total_params=0
        for name, mask in masks.items():
            total_params+=tf.size(mask)
        #print("total number of params", total_params)
        is_epsilon_valid=False
        dense_layers = set() #ensemble note entre {}, les elements du set sont non ordonne, inchangeable et on n'a pas de valeur en double
        while not is_epsilon_valid:
            print("searching for the right epsilon")
            divisor = 0
            rhs = 0
            raw_probabilities = {}#dictionnaire
            #le but de cette boucle est de trouver les layer pour qui la sparsity doit etre 0
            for name, mask in masks.items():
                #print("name", name)
                #print("mask",mask)
                n_param = np.prod(mask.shape) #retourne le produit des elements de shape(donc produit des dim du tensor) pour avoir le nb d'elements/poids du tensor
                #print("n_param", n_param)
                n_zeros = n_param * (1 - self.density) #nb de param a mettre a zero (a elaguer), density c'est le pourcentage de poids a garder
                n_ones = n_param * self.density #nb de param a mettre a 1 

                if name in dense_layers:
                    #print("if dense_layers")
                    rhs -= n_zeros #on soustrait le nb de param elagues
                else:
                    #print("not dense layers")
                    rhs += n_ones #on rajoute le nb de param non elagues
                    raw_probabilities[name] = (#je pense pourcentage de poids a elaguer/ raw_probabilities est un dictionnaire qui contient la proba associe a chaque tensor de poids qui a la cle name
                                                        np.sum(mask.shape[:2]) / np.prod(mask.shape[:2]) #somme des dim du tensor/produit des dim, le produit des dim c'est le nb d'element
                                                ) ** self.erk_power_scale #doit etre un param de erk
                    #print(raw_probabilities[name])
                    divisor += raw_probabilities[name] * n_param #je pense c'est le nb de poids qu'on garde
            epsilon = rhs / divisor #divisor je pense c'est le nb total de poids qu'on garde et
                                    #rhs c'est un peu un compteur a qui on rajoute le nb de poids non elagues et on deduit le nb de poids elagues
            max_prob = np.max(list(raw_probabilities.values()))#on prend le max des values du dictionnaies
            max_prob_one = max_prob * epsilon#proba d'elagage max *epsilon je pense
            if max_prob_one > 1:
                is_epsilon_valid = False
                for mask_name, mask_raw_prob in raw_probabilities.items():#items c'est les elem du dictionnaire en (cle, valeur)
                    if mask_raw_prob == max_prob:
                        print(f"Sparsity of var:{mask_name} had to be set to 0.")
                        dense_layers.add(mask_name)
            else:
                is_epsilon_valid = True
                

        #print("rhs", rhs, "divisor", divisor, "epsilon", epsilon)
        #print("raw_probabilities",raw_probabilities)
        density_dict = {}
        total_nonzero = 0.0
        # With the valid epsilon, we can set sparsities of the remaning layers.
        for name, mask in masks.items():
            n_param = np.prod(mask.shape)
            if name in dense_layers:
                density_dict[name] = 1.0
            else:
                probability_one = epsilon * raw_probabilities[name]
                density_dict[name] = probability_one
            print(
                f"layer: {name}, shape: {mask.shape}, density: {density_dict[name]}"
            )
            
            masks[name] = tf.cast(tf.random.uniform(mask.shape, minval=0, maxval=1, dtype=tf.dtypes.float32) < density_dict[name], float)
            
            
        return masks