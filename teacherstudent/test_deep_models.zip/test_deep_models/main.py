#@title Import libraries {display-mode: "form"}

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
#import tensorflow_datasets as tfds
from collections import Counter
from collections import defaultdict

#from tqdm import tqdm
from copy import deepcopy
from absl import logging

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

import shutil
import time
import math
import random
import os
import subprocess
import signal
import pickle



import growneuron.layers as glayers
from growneuron import growers
from growneuron import updaters


from prune import Pruner, RandomERPruner, MagnetitudePruner

print(tf.config.get_visible_devices())
tf.config.set_visible_devices(tf.config.get_visible_devices()[0])
print('device', tf.config.get_visible_devices())


#@title Model and Experiment Definition
class DenseModel_grow(tf.keras.Model):
    def __init__(self, n_neurons, activation='relu1', use_bn=False, use_bias=False):
        super(DenseModel_grow, self).__init__()
        self.n_neurons = n_neurons
        self.use_bn = use_bn
        self.layers_seq = []
        for i, n_neuron in enumerate(n_neurons):
            if i == (len(n_neurons) - 1):
                layer = tf.keras.layers.Dense(n_neuron, use_bias=use_bias, name=f'last_layer')
                self.layers_seq.append(glayers.GrowLayer(layer))
            else:
                layer = tf.keras.layers.Dense(n_neuron, use_bias=use_bias, name=f'dense_{i}')
                self.layers_seq.append(glayers.GrowLayer(layer, activation=activation))
            if use_bn:
                self.layers_seq.append(glayers.GrowLayer(tf.keras.layers.BatchNormalization()))

    def call(self, x, is_debug=False):
        """Regular forward pass on the layer."""
        for layer in self.layers_seq:
            if is_debug: print(x[0])
            x = layer(x)
        return x

    def get_grow_layer_tuples(self):
        """Gets all groups of layers that need to grow together."""

        grow_layers = [
            i for i, l in enumerate(self.layers_seq)
            if (isinstance(l, glayers.GrowLayer) and
                isinstance(l.layer, tf.keras.layers.Dense))
        ]

        grow_layer_tuples = []
        for i, j in zip(grow_layers[:-1], grow_layers[1:]):
          # Grow tuples should be in order.
          grow_layer_tuples.append(self.layers_seq[i:(j+1)])
        return grow_layer_tuples
        
        
def train_w_data_select(n_neurons=(5, 5), data=None, data_dim=10, actv_fn='relu', lr=1e-2, ckpt_prefix='tf_ckpts',
                        is_print=False, optim_type='sgd', use_bias=False, nb_epochs=1, selectivity=0.5):
    print("training with data selection, selectivity=", selectivity)
    print("checking all_data in train method", len(data))
    
    save_step = 100  # save the model every 100 steps
    start = time.time()
    stats = defaultdict(list)
    
    
    print("Optimizer:", optim_type)
    if optim_type == 'sgd':
        optimizer = tf.keras.optimizers.SGD(learning_rate=lr)
    elif optim_type == 'momentum_true':
        optimizer = tf.keras.optimizers.SGD(learning_rate=lr, momentum=0.9)
    elif optim_type == 'adam_true':
        optimizer = tf.keras.optimizers.Adam(learning_rate=lr)
    
    student_model = DenseModel_grow(n_neurons, activation=actv_fn, use_bn=False, use_bias=use_bias)
    
    def get_loss(unused_arg=None, x=None,y=None):
        del unused_arg
        pred = student_model(x)
        loss_fn = tf.keras.losses.MeanSquaredError()
        return loss_fn(y, pred)
    
    #on fait un build pour que les poids du modele soit créés
    student_model.build(input_shape=[None, data_dim]) #input_shape=[taille_batch, dim_input]
    #data_dim c'est le dimension des données en entrée
    print("Summary of student model")
    for i in range(len(student_model.layers)):
        weights=student_model.layers[i].get_weights()[0]
        print(weights.shape)
        
    
    student_model.compile(optimizer=optimizer, loss=tf.keras.losses.MeanSquaredError())
    
    ckpt = tf.train.Checkpoint(net=student_model)
    ckpt_path = f'./{ckpt_prefix}_{i}'
    manager = tf.train.CheckpointManager(ckpt, ckpt_path, max_to_keep=None)
    if os.path.exists(ckpt_path) and os.path.isdir(ckpt_path):
        shutil.rmtree(ckpt_path)
        
    stats['loss_curves'].append([])
    stats['loss_times'].append([])
    stats['time_per_batch'].append([])
    stats['gnorm_curves'].append([])
    stats['gnorm_l1_curves'].append([])
    stats['gnorm_l2_curves'].append([])
    
    print("################################### training starts ###################################")
    nb_total_iters=0
    nb_selected_batches=0
    nb_not_selected_batches=0
    
    for epoch in range(nb_epochs):
        #print("epoch",epoch,"/",nb_epochs)
        for i, (x_train, y_train) in enumerate(data):
            #=====> generer la proba de selection du batch
            batch_time_start=time.time()
            nb_total_iters+=1
            rand_flag = random.uniform(0, 1) > selectivity
            #cas où le batch n'est pas sélectionné
            """if ((i==0) and (epoch==0)): #si c'est le premier barc de la premire epoch on ne selectionne pas pour des contranites d'implementation
                select=False
            else:
                select=True"""
            if rand_flag:
                nb_not_selected_batches+=1
                if (nb_selected_batches>0):
                    optimizer.apply_gradients(zip(all_grads, variables))
                #print("batch not selected")
                continue

            #print("batch selected")
            nb_selected_batches+=1
            with tf.GradientTape() as tape:
                loss = get_loss(x=x_train, y=y_train)
            variables = student_model.trainable_variables
            all_grads = tape.gradient(loss, variables)
            optimizer.apply_gradients(zip(all_grads, variables))
            stats['gnorm_curves'][-1].append(tf.norm(flatten_list_of_vars(all_grads)).numpy())
            stats['gnorm_l1_curves'][-1].append(tf.norm(all_grads[0]).numpy())
            stats['gnorm_l2_curves'][-1].append(tf.norm(all_grads[1]).numpy())
            stats['loss_curves'][-1].append(loss.numpy())
            cur_time=time.time()
            stats['loss_times'][-1].append(cur_time - start)
            batch_time_end=time.time()
            stats['time_per_batch'][-1].append(batch_time_end - batch_time_start)
        
        
        
            
        
    end = time.time()
    stats['runtime'].append(end - start)
    print("runtime", stats['runtime'])
    print("last loss",loss)
    print("nb total batches", nb_total_iters, "nb selected batches", nb_selected_batches, "nb not selected batches",nb_not_selected_batches)
    
    
    
    
    return student_model, stats


def run_experiments_data_select(seed=0, all_data=None, width=10, actv_fn = 'relu', n_data=1000, use_bias=False, student_width=None,
                    lr=0.01, weights_range=1., optim_type='momentum_true', total_steps=1500, batch_size=100, selectivity=0.5,in_dim=100):
    print("Starting experiments")
    
    print("checking all_data", len(all_data))
    student_width = width #pour la data selection le student et le teacher ont la meme structure
    in_dim, out_dim = in_dim, 10
    
    print("the number of epoch is set as the number of iterations divided by the batch size")
    nb_epochs=int(total_steps/batch_size)
    print("total_steps", total_steps, "batch_size", batch_size, "nb_epochs", nb_epochs)
    
    tf.random.set_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    
    baseline_kwargs = {
      'n_neurons': student_width,
      'use_bias': use_bias,
      'actv_fn': actv_fn,
      'data': all_data,
      'data_dim':in_dim, #nécessaire pour le build du student
      'optim_type': optim_type,
      'lr': lr,
      'nb_epochs': nb_epochs,
      'selectivity':selectivity,
      }
    stats = {}
    
    new_kwargs = baseline_kwargs.copy()
    
    print_kwargs = new_kwargs.copy()
    print_kwargs['data'] = None
    print(print_kwargs)
    _, stats= train_w_data_select(ckpt_prefix=f'{width}', **new_kwargs)
    print("############ end ###################")
    return stats


#a slightly different data selection code where we do a forward pass even when the batch is skipped, we need it to have plots with the same number of elements in x axis for all approaches
def train_w_data_select_curve(n_neurons=(5, 5), data=None, data_dim=10, actv_fn='relu', lr=1e-2, ckpt_prefix='tf_ckpts', 
                        is_print=False, optim_type='sgd', use_bias=False, nb_epochs=1, selectivity=0.5):
    print("training with data selection, selectivity=", selectivity)
    print("checking all_data in train method", len(data))
    
    save_step = 100  # save the model every 100 steps
    
    stats = defaultdict(list)
    
    start = time.time()
    print("Optimizer:", optim_type)
    if optim_type == 'sgd':
        optimizer = tf.keras.optimizers.SGD(learning_rate=lr)
    elif optim_type == 'momentum_true':
        optimizer = tf.keras.optimizers.SGD(learning_rate=lr, momentum=0.9)
    elif optim_type == 'adam_true':
        optimizer = tf.keras.optimizers.Adam(learning_rate=lr)
    
    student_model = DenseModel_grow(n_neurons, activation=actv_fn, use_bn=False, use_bias=use_bias)
    
    def get_loss(unused_arg=None, x=None,y=None):
        del unused_arg
        pred = student_model(x)
        loss_fn = tf.keras.losses.MeanSquaredError()
        return loss_fn(y, pred)
    
    #on fait un build pour que les poids du modele soit créés
    student_model.build(input_shape=[None, data_dim]) #input_shape=[taille_batch, dim_input]
    #data_dim c'est le dimension des données en entrée
    print("Summary of student model")
    for i in range(len(student_model.layers)):
        weights=student_model.layers[i].get_weights()[0]
        print(weights.shape) 
        
     
    student_model.compile(optimizer=optimizer, loss=tf.keras.losses.MeanSquaredError())
    
    ckpt = tf.train.Checkpoint(net=student_model)
    ckpt_path = f'./{ckpt_prefix}_{i}'
    manager = tf.train.CheckpointManager(ckpt, ckpt_path, max_to_keep=None)
    if os.path.exists(ckpt_path) and os.path.isdir(ckpt_path):
        shutil.rmtree(ckpt_path)
        
    stats['loss_curves'].append([])
    stats['loss_times'].append([])
    stats['time_per_batch'].append([])
    stats['gnorm_curves'].append([])
    stats['gnorm_l1_curves'].append([])
    stats['gnorm_l2_curves'].append([])
    
    
    print("################################### training starts ###################################")
    nb_total_iters=0
    nb_selected_batches=0
    nb_not_selected_batches=0
    
    for epoch in range(nb_epochs):
        #print("epoch",epoch,"/",nb_epochs)
        for i, (x_train, y_train) in enumerate(data):
            #=====> generer la proba de selection du batch
            batch_time_start=time.time()
            nb_total_iters+=1
            rand_flag = random.uniform(0, 1) > selectivity
            if rand_flag:
                nb_not_selected_batches+=1
                if (nb_selected_batches>0):
                    optimizer.apply_gradients(zip(all_grads, variables))
                #print("batch not selected")
                stats['loss_curves'][-1].append(get_loss(x=x_train, y=y_train))
                continue

            #print("batch selected")
            nb_selected_batches+=1
            with tf.GradientTape() as tape:
                loss = get_loss(x=x_train, y=y_train)
            variables = student_model.trainable_variables
            all_grads = tape.gradient(loss, variables)
            optimizer.apply_gradients(zip(all_grads, variables))
            stats['gnorm_curves'][-1].append(tf.norm(flatten_list_of_vars(all_grads)).numpy())
            stats['gnorm_l1_curves'][-1].append(tf.norm(all_grads[0]).numpy())
            stats['gnorm_l2_curves'][-1].append(tf.norm(all_grads[1]).numpy())
            stats['loss_curves'][-1].append(loss.numpy())
            cur_time=time.time()
            stats['loss_times'][-1].append(cur_time - start)
            batch_time_end=time.time()
            stats['time_per_batch'][-1].append(batch_time_end - batch_time_start)
        
        
            
    
    end = time.time()
    stats['runtime'].append(end - start)
    print("runtime", stats['runtime'])
    print("last loss",loss)
    print("nb total batches", nb_total_iters, "nb selected batches", nb_selected_batches, "nb not selected batches",nb_not_selected_batches)
    
    
    
    
    return student_model, stats


def run_experiments_data_select_curve(seed=0, all_data=None, width=10, actv_fn = 'relu', n_data=1000, use_bias=False, student_width=None,
                    lr=0.01, weights_range=1., optim_type='momentum_true', total_steps=1500, batch_size=100, selectivity=0.5, in_dim=100):
    print("Starting experiments")
    
    print("checking all_data", len(all_data))
    student_width = width #pour la data selection le student et le teacher ont la meme structure
    in_dim, out_dim = in_dim, 10
    
    print("the number of epoch is set as the number of iterations divided by the batch size")
    nb_epochs=int(total_steps/batch_size)
    print("total_steps", total_steps, "batch_size", batch_size, "nb_epochs", nb_epochs)
    
    tf.random.set_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    
    baseline_kwargs = {
      'n_neurons': student_width, 
      'use_bias': use_bias,
      'actv_fn': actv_fn,
      'data': all_data,
      'data_dim':in_dim, #nécessaire pour le build du student
      'optim_type': optim_type,
      'lr': lr,
      'nb_epochs': nb_epochs,
      'selectivity':selectivity,
      } 
    stats = {}
    
    new_kwargs = baseline_kwargs.copy()
    
    print_kwargs = new_kwargs.copy()
    print_kwargs['data'] = None
    print(print_kwargs)
    _, stats= train_w_data_select_curve(ckpt_prefix=f'{width}', **new_kwargs)
    print("############ end ###################")
    return stats
    
    
    
def flatten_list_of_vars(var_list):
    flat_vars = [tf.reshape(v, -1) for v in var_list]
    return tf.concat(flat_vars, axis=-1)

def train_w_growth(growth_type=None, n_neurons=(5, 5), n_growth_steps=5, growth_interval=200,
                   data=None, actv_fn='relu1', layer_id=0, lr=1e-2, ckpt_prefix='tf_ckpts', is_print=False,
                   num_to_add=1, total_steps=1200, scale=1.0, optim_type='sgd', use_bias=False,
                   start_iter=None, batch_size=100, data_dim=20):
    print('Training with growth type: ', growth_type)
    print("checking all_data in train method", len(data))
    save_step = 100  # save the model every 100 steps
    start_iter = growth_interval if start_iter is None else start_iter
    total_steps += start_iter
    print('rt', total_steps)
    
    print("the number of epoch is set as the number of iterations divided by the batch size")
    nb_epochs=int(total_steps*10/batch_size) #on fait total_steps*10 pour avoir le meme nb de batch traité avec la sélection de données
    #le *10 c'est le nombre de batch (on multiplie par le nb de batch pour avoir le bon nb d'itérations)
    print("total_steps", total_steps, "batch_size", batch_size, "nb_epochs", nb_epochs)
    start = time.time()
    stats = defaultdict(list)
    
    
    print("Optimizer:", optim_type)
    print("choix optimizer:", optim_type)
    if optim_type == 'sgd':
        optimizer = tf.keras.optimizers.SGD(learning_rate=lr)
        carry_optimizer = False #If true the running averages are carried to the new
    elif optim_type == 'momentum_true':
        optimizer = tf.keras.optimizers.SGD(learning_rate=lr, momentum=0.9)
        carry_optimizer = True
    elif optim_type == 'momentum_false':
        optimizer = tf.keras.optimizers.SGD(learning_rate=lr, momentum=0.9)
        carry_optimizer = False
    elif optim_type == 'adam_true':
        optimizer = tf.keras.optimizers.Adam(learning_rate=lr)
        carry_optimizer = True
    elif optim_type == 'adam_false':
        optimizer = tf.keras.optimizers.Adam(learning_rate=lr)
        carry_optimizer = False


    student_model = DenseModel_grow(n_neurons, activation=actv_fn, use_bn=False, use_bias=use_bias)
    
    def get_loss( x,y, unused_arg=None):
        del unused_arg
        pred = student_model(x)
        loss_fn = tf.keras.losses.MeanSquaredError()
        return loss_fn(y, pred)
    
    ## compile_fn et loss_fn2 on les crée pour s'adapter au code du fichier updater de gradmax
    def loss_fn2(inputs):
        x,y=inputs
        pred = student_model(x)
        loss_fn = tf.keras.losses.MeanSquaredError()
        return loss_fn(y, pred)
        
    
    def compile_fn():
        student_model(tf.random.normal(shape=[1, in_dim]))
    
    #on fait un build pour que les poids du modele soit créés
    student_model.build(input_shape=[None, data_dim]) #input_shape=[taille_batch, dim_input]
    #data_dim c'est le dimension des données en entrée
    print("Summary of student model before growing")
    for i in range(len(student_model.layers)):
        weights=student_model.layers[i].get_weights()[0]
        print(weights.shape)
    
  
    student_model.compile(optimizer=optimizer, loss=tf.keras.losses.MeanSquaredError())
    
    ckpt = tf.train.Checkpoint(net=student_model)
    ckpt_path = f'./{ckpt_prefix}_{i}'
    manager = tf.train.CheckpointManager(ckpt, ckpt_path, max_to_keep=None)
    if os.path.exists(ckpt_path) and os.path.isdir(ckpt_path):
        shutil.rmtree(ckpt_path)
        
    if growth_type == 'gradmax':
        grower = growers.AddGradmax()
    elif growth_type == 'random':
        grower = growers.AddRandom()
    elif growth_type == 'random_zeros':
        grower = growers.AddRandom()
        grower.is_all_zero = True
    elif growth_type == 'random_inverse':
        grower = growers.AddRandom()
        grower.is_outgoing_zero = True
    elif growth_type == 'gradmax_opt_inverse':
        grower = growers.AddGradmaxOptimInverse()
    elif growth_type == 'gradmax_opt':
        grower = growers.AddGradmaxOptim()
        grower.optim_fn = lambda: tf.keras.optimizers.Adam()
    else: #notamment pour baselinebig et baselinesmall car on utilise le meme code
        print('No growing')
        grower = None



    layers_to_grow = student_model.get_grow_layer_tuples()
    """updater = updaters.RoundRobin(grower, layers_to_grow, loss_fn=loss_fn2,
                                  compile_fn=compile_fn,
                                  update_frequency=growth_interval,
                                  start_iteration=start_iter,
                                  n_growth_steps=n_growth_steps,
                                  n_grow=num_to_add,
                                  carry_optimizer=carry_optimizer,
                                  scale=scale)"""
    
    updater = updaters.AllAtOnce(grower, layers_to_grow, loss_fn=loss_fn2,
                                  compile_fn=compile_fn,
                                  update_frequency=growth_interval,
                                  start_iteration=start_iter,
                                  n_growth_steps=5,
                                  n_grow=num_to_add,
                                  carry_optimizer=carry_optimizer,
                                  scale=scale)
    
    stats['loss_curves'].append([])
    stats['loss_times'].append([])
    stats['time_per_batch'].append([])
    stats['gnorm_curves'].append([])
    stats['gnorm_l1_curves'].append([])
    stats['gnorm_l2_curves'].append([])
    
    print("debut training, total steps=",total_steps)
    
    print("################################### training starts ###################################")
    step=0 #compte le nb d'iter total (nb batches total qlq soit l'epoch)
    print("nb_epoch", nb_epochs)
    
    for epoch in range(nb_epochs):
        #print("epoch",epoch,"/",nb_epochs)
        for i, (x_train, y_train) in enumerate(data):
            #=====> generer la proba de selection du batch
            #print("###################################")
            batch_time_start=time.time()
            step+=1
            #print(step)
            with tf.GradientTape() as tape:
                loss = get_loss(x=x_train, y=y_train)
            variables = student_model.trainable_variables
            all_grads = tape.gradient(loss, variables)
            optimizer.apply_gradients(zip(all_grads, variables))
            stats['gnorm_curves'][-1].append(tf.norm(flatten_list_of_vars(all_grads)).numpy())
            stats['gnorm_l1_curves'][-1].append(tf.norm(all_grads[0]).numpy())
            stats['gnorm_l2_curves'][-1].append(tf.norm(all_grads[1]).numpy())
            stats['loss_curves'][-1].append(loss.numpy())
            cur_time=time.time()
            stats['loss_times'][-1].append(cur_time - start)
            if updater.is_update_iteration(step):
                #print("=====> growth step at iteration", step)
                save_path = manager.save()
                stats['ckpt_path'].append(save_path)
                # on crée ce inputs pour communiquer le batch à update_network
                inputs=(x_train, y_train)
                updater.update_network(inputs, num_to_add, optimizer=optimizer)
                #print('growing')
                #if is_print:
                #    print('n_neurons', student_model.layers_seq[layer_id].units)
            batch_time_end=time.time()
            stats['time_per_batch'][-1].append(batch_time_end - batch_time_start)
        
        
            
    
    end = time.time()
    print("Summary of student model after growing")
    for i in range(len(student_model.layers)):
        weights=student_model.layers[i].get_weights()[0]
        print(weights.shape)
    stats['runtime'].append(end - start)
    print("runtime of", growth_type, "is", stats['runtime'])
    print("last loss of", growth_type, "is",loss)
    print("nb total steps", step)
    
    
    
        
    return student_model, stats

def run_experiments_growing(values, key, seed=0,width=10, actv_fn = 'relu1',
                            n_data=1000, num_to_add=1, final_steps=500, scale=1.0, use_bias=False,start_iter = None,
                            n_growth_multiplier = 1, student_width=None, lr=0.01, n_repeat=1, growth_interval=200,
                            growth_type='baseline_small', weights_range=1., optim_type='momentum_true', all_data=None,
                           batch_size=100, in_dim=100):
    print("starting expermeiments")
    
    
    in_dim, out_dim = in_dim, 10
    
    student_width=[1 for k in range(len(width))]
    n_growth=[1 for k in range(len(width))]
    
    for k in range(len(width)):
        if (width[k] % 2) != 0:
            raise ValueError(f'width: {width} needs to divide by 2.')
        
        student_width[k] = width[k] // 2
        

        
        """if ((width[k] - student_width[k]) % num_to_add[k]) != 0:
            raise ValueError(f'width: {width[k]} needs to devide by {num_to_add[k]}')"""
        if (num_to_add[k]==0):
            n_growth[k]=5
        else:
            n_growth[k] = (width[k] - student_width[k]) // num_to_add[k]
        if n_growth_multiplier != 1:
            n_growth[k] = int(n_growth[k] * n_growth_multiplier)

    student_width[-1]=student_width[-1]*2
    
    
    n_n_growth=5    
    total_steps = (n_n_growth-1) * growth_interval + final_steps
    
    print(total_steps)
    baseline_kwargs = {
      'n_neurons': student_width,
      'n_growth_steps': n_growth,
      'growth_type': growth_type,
      'total_steps': total_steps,
      'num_to_add': num_to_add,
      'use_bias': use_bias,
      'start_iter': start_iter,
      'actv_fn': actv_fn,
      'data': all_data,
      'optim_type': optim_type,
      'growth_interval': growth_interval,
      'lr': lr,
      'scale': scale,
      'batch_size':batch_size,
      'data_dim':in_dim
      }
    stats = {}
    for val in values:
        tf.random.set_seed(seed)
        np.random.seed(seed)
        random.seed(seed)
        print(f'{key}: {val}')
        new_kwargs = baseline_kwargs.copy()
        new_kwargs[key] = val
        if new_kwargs['growth_type'] == 'baseline_big':
            new_kwargs['n_neurons'] = width
        print_kwargs = new_kwargs.copy()
        print_kwargs['data'] = None
        print(print_kwargs)
        print("on entraine le student")
        _, stats[val] = train_w_growth(ckpt_prefix=f'{width[1]}_{val}', **new_kwargs)
    print("############ fin ###################")
    return stats, all_data
    
    
def train_w_pruning(pruning_type='erk_random', pruning_density=0.5, n_neurons=(5, 5), data=None,
                    data_dim=10, actv_fn='relu', lr=1e-2, ckpt_prefix='tf_ckpts', is_print=False, total_steps=1500,
                    optim_type='sgd', use_bias=False, nb_epochs=1):
    save_step = 100  # save the model every 100 steps
    print("num total steps:", total_steps)
    start = time.time()
    stats = defaultdict(list)
    
    
    print("Optimizer:", optim_type)
    if optim_type == 'sgd':
        optimizer = tf.keras.optimizers.SGD(learning_rate=lr)
    elif optim_type == 'momentum_true':
        optimizer = tf.keras.optimizers.SGD(learning_rate=lr, momentum=0.9)
    elif optim_type == 'adam_true':
        optimizer = tf.keras.optimizers.Adam(learning_rate=lr)

    student_model = DenseModel_grow(n_neurons, activation=actv_fn, use_bn=False, use_bias=use_bias)
    
    def get_loss(unused_arg=None, x=None,y=None):
        del unused_arg
        pred = student_model(x)
        loss_fn = tf.keras.losses.MeanSquaredError()
        return loss_fn(y, pred)
    
    #on fait un build pour que les poids du modele soit créés
    student_model.build(input_shape=[None, data_dim]) #input_shape=[taille_batch, dim_input]
    #data_dim c'est le dimension des données en entrée
    
    print("summary of student model")
    for i in range(len(student_model.layers)):
        weights=student_model.layers[i].get_weights()[0]
        print(weights.shape)
        
            
    
    print("pruning type", pruning_type)
    
    if pruning_type=='erk_random':
        pruner=RandomERPruner(arch=student_model, data=None, density=pruning_density)
        masks=pruner.compute_pruning_masks()
        if (pruning_density==0.):
            print("nothing to prune, keeping the original network")
            masks=None
        elif (pruning_density==1.):
            print("nothing to prune, keeping the entire network")
            masks=None
        else:
            #print("obtained masks", masks)
            pruner.apply_masks(masks)
            print("Pruning the network")
            #calcul de la sparsity obtenue
            nb_zeros=0
            nb_elems=0
            for key in masks.keys():
                #print(masks[key])
                nb_ones=tf.get_static_value(tf.math.count_nonzero(masks[key]))
                nb_zeros+=tf.get_static_value(tf.size(masks[key]))-nb_ones
                nb_elems+=tf.get_static_value(tf.size(masks[key]))
            print("given density",pruning_density,"resulting density", 1-nb_zeros/nb_elems)


    elif pruning_type=='magnetitude_before_train':
        pruner=MagnetitudePruner(arch=student_model, data=None, density=pruning_density)
        num_parameters_to_keep, masks=pruner.compute_pruning_masks()
        if num_parameters_to_keep==0:
            print("can't apply pruning, training the original network")
            masks=None
        elif (num_parameters_to_keep!=1 and masks is None): #on garde tous les param car num_paramets_to_keep=nb poids du network
            print("nothing to prune, keeping the entire network")
            masks=None
        else:
            #print("obtained masks", masks)
            pruner.apply_masks(masks)
            print("Pruning the network")
            #calcul de la sparsity obtenue
            nb_zeros=0
            nb_elems=0
            for key in masks.keys():
                #print(masks[key])
                nb_ones=tf.get_static_value(tf.math.count_nonzero(masks[key]))
                nb_zeros+=tf.get_static_value(tf.size(masks[key]))-nb_ones
                nb_elems+=tf.get_static_value(tf.size(masks[key]))
            print("given density",pruning_density,"resulting density", 1-nb_zeros/nb_elems)

    elif pruning_type=='random':
        pruner= Pruner(arch=student_model, data=None, density=pruning_density)
        if (pruning_density==0.):
            print("nothing to prune, keeping the original network")
            masks=None
        elif (pruning_density==1.):
            print("nothing to prune, keeping the entire network")
            masks=None
        else: #on génère des masks aléatoires
            masks={}
            for i in range(len(student_model.layers)):
                weights=student_model.layers[i].get_weights()[0]
                name=getattr(student_model.layers[i], 'name')
                mask=tf.cast(tf.random.uniform(weights.shape, minval=0, maxval=1, dtype=tf.dtypes.float32) < pruning_density
                              , float)
                masks[name]=mask

            print("obtained masks", masks)
            pruner.apply_masks(masks)
            print("Pruning the network")
            #calcul de la sparsity obtenue
            nb_zeros=0
            nb_elems=0
            for key in masks.keys():
                #print(masks[key])
                nb_ones=tf.get_static_value(tf.math.count_nonzero(masks[key]))
                nb_zeros+=tf.get_static_value(tf.size(masks[key]))-nb_ones
                nb_elems+=tf.get_static_value(tf.size(masks[key]))
            print("given density",pruning_density,"resulting density", 1-nb_zeros/nb_elems)

    else:
        print("pruning method not implemented")
        import sys
        sys.exit()

    
    student_model.compile(optimizer=optimizer, loss=tf.keras.losses.MeanSquaredError())


    ckpt = tf.train.Checkpoint(net=student_model)
    ckpt_path = f'./{ckpt_prefix}_{i}'
    manager = tf.train.CheckpointManager(ckpt, ckpt_path, max_to_keep=None)

    if os.path.exists(ckpt_path) and os.path.isdir(ckpt_path):
        shutil.rmtree(ckpt_path)
        
    stats['loss_curves'].append([])
    stats['loss_times'].append([])
    stats['time_per_batch'].append([])
    stats['gnorm_curves'].append([])
    stats['gnorm_l1_curves'].append([])
    stats['gnorm_l2_curves'].append([])
    
    print("starting training")
    nb_total_iters=0
    
    for epoch in range(nb_epochs):
        #print("epoch",epoch,"/",nb_epochs)
        for i, (x_train, y_train) in enumerate(data):
            batch_time_start=time.time()
            nb_total_iters+=1
            with tf.GradientTape() as tape:
                loss = get_loss(x=x_train, y=y_train) #phase forward et calcul loss
            variables = student_model.trainable_variables
            all_grads = tape.gradient(loss, variables)
            ###################### IMPORTANT ###########################
            # je n'ai pas trouver une façon d'exclure les poids élagués du training
            # donc leur gradients sont calculés
            # si on garde les gradients calculés et qu'on fait l'update les poids élagués ne seront plus a zero
            # donc soit on fait l'update puis on réapplique les masques
            # ou bien on applique le mask sur all_grads (les gradients) pour que les gradients des poids élagués soient mis
            # a zero et c'est ce que j'ai fait
            # de cette facon durant l'update les poids elagués reste a zero
            #on peut faire un slicing de student_model.trainable_variables mais on change les dimension des matrices
            #si on veut éviter ça il faut customizer apply_gradients
            
            if (masks is not None):
                for gg in range(len(all_grads)):
                    all_grads[gg]= all_grads[gg]*list(masks.values())[gg]
                
            
            optimizer.apply_gradients(zip(all_grads, variables))
            stats['gnorm_curves'][-1].append(tf.norm(flatten_list_of_vars(all_grads)).numpy())
            stats['gnorm_l1_curves'][-1].append(tf.norm(all_grads[0]).numpy())
            stats['gnorm_l2_curves'][-1].append(tf.norm(all_grads[1]).numpy())
            stats['loss_curves'][-1].append(loss.numpy())
            cur_time=time.time()
            stats['loss_times'][-1].append(cur_time - start)
            batch_time_end=time.time()
            stats['time_per_batch'][-1].append(batch_time_end - batch_time_start)
            
        #print("starting eval")
        
        
            
    end = time.time()
    stats['runtime'].append(end - start)
    
    total_size=0
    sparse_size=0
    for i in range(len(student_model.layers)):
        name=getattr(student_model.layers[i], 'name')
        weight=student_model.layers[i].weights[0]
        print(name, 'density:',np.sum((weight!=0))/tf.size(weight))
        total_size+=tf.size(weight)
        sparse_size+=np.sum((weight!=0))
    print("global sparsity", sparse_size/total_size, "for density", pruning_density)

    print("runtime of", pruning_type, "is", stats['runtime'])
    print("last loss of", pruning_type, "is", loss)
    print("nb total batches", nb_total_iters)
    
    
    return student_model, stats


def run_experiments_pruning(values, key, seed=0, width=10, actv_fn = 'relu', n_data=1000, use_bias=False, student_width=None,
                    lr=0.01, n_repeat=1, pruning_type='erk_random', pruning_density=0.5, weights_range=1.,
                    optim_type='momentum_true', total_steps=1500, batch_size=100, all_data=None, in_dim=100):
    print("starting expermeiments")
    
    
    in_dim, out_dim = in_dim, 10
    
    
    print("num total steps", total_steps)
    print("the number of epoch is set as the number of iterations divided by the batch size")
    nb_epochs=int(total_steps/batch_size)
    print("total_steps", total_steps, "batch_size", batch_size, "nb_epochs", nb_epochs)
    
    baseline_kwargs = {
      'n_neurons': student_width,
      'total_steps': total_steps,
      'use_bias': use_bias,
      'actv_fn': actv_fn,
      'data': all_data,
      'data_dim':in_dim, #nécessaire pour le build du student
      'optim_type': optim_type,
      'lr': lr,
      'pruning_type':pruning_type,
      'pruning_density':pruning_density,
      'nb_epochs': nb_epochs
      }
    stats = {}
    
    for val in values:
        tf.random.set_seed(seed)
        np.random.seed(seed)
        random.seed(seed)
        print(f'{key}: {val}')
        new_kwargs = baseline_kwargs.copy()
        new_kwargs[key] = val
        print_kwargs = new_kwargs.copy()
        print_kwargs['data'] = None
        print(print_kwargs)
        print("training the student")
        _, stats[val] = train_w_pruning(ckpt_prefix=f'{width[1]}_{val}', **new_kwargs)
    print("############ end ###################")
    return stats
    
    
width=[50, 40, 30, 20, 10]
in_dim, out_dim = 100, 10
total_steps=3500
actv_fn='relu'
use_bias=False
weights_range=1.
n_data=5000
batch_size=100
nb_exec=10
seed_vect=list(range(nb_exec))

dico_global_data_select_20={}
dico_global_data_select_50={}
dico_global_data_select_20_curve={}
dico_global_data_select_50_curve={}
dico_global_data_select_13_curve={}
dico_global_data_select_15_curve={}
dico_global_data_select_17_curve={}
dico_global_gradmax={}
dico_global_baseline_small={}
dico_global_baseline_big={}
dico_global_pruning_erk={}

def get_power_stats(file, train_time):
    f=open(file, 'r')
    lines = f.readlines()
    power_list=[]
    power_avg=0
    
    for line in lines:
        if ('\\n') in line:
            line=line.replace('\\n', '')
        power_list.append(int(line))
        power_avg+=int(line)

    power_avg/=len(lines)
    power_avg/=1000 #conversion en watt
    energy= power_avg * train_time
    tr_time=len(lines)
    return power_avg, tr_time, energy

def generate_data():
    teacher_model = DenseModel_grow(width, activation=actv_fn, use_bias=use_bias)

    # Init variables
    #teacher_model(tf.random.normal(shape=[1, out_dim]))
    teacher_model(tf.random.normal(shape=[1, in_dim]))


    for layer in teacher_model.layers_seq:
        if layer.weights:
            layer.weights[0].assign(
              tf.random.uniform(layer.weights[0].shape,
                                minval=-weights_range, maxval=weights_range))

    print("Summary du teacher model")
    for i in range(len(teacher_model.layers)):
        weights=teacher_model.layers[i].get_weights()[0]
        print(weights.shape)

    print("generating the dataset")
    nb_batch=int(n_data/batch_size)

    print("we generate", nb_batch, "batches with batch_size", batch_size)

    all_data=[]
    for nb in range(nb_batch):
        #x_train = tf.random.normal(shape=[batch_size, out_dim])
        x_train = tf.random.normal(shape=[batch_size, in_dim])
        y_train = teacher_model(x_train)
        all_data.append((x_train, y_train))
    return (all_data)
    
    
for n in range(nb_exec):
    print("----------------------------------------------------------------------------------")
    print("execution number", n, "with seed", seed_vect[n])
    seed=seed_vect[n]
    all_data=generate_data()
    
    
    print("data select 20%")
    path='/Users/Anais/Desktop/test_ts/data_select_20_seed_'+str(seed)+'_test.txt'
    command='sudo powermetrics -i 1000 | grep "Combined Power" --line-buffered | awk \'{print $8 > "/Users/Anais/Desktop/test_ts/data_select_20_seed_'+str(seed)+'_test.txt"}\''
    pro = subprocess.Popen(command, shell=True, start_new_session=True)
    time.sleep(1)
    stats_test_data_20 = run_experiments_data_select(seed=seed,all_data=all_data, width=width, n_data=5000,batch_size=100, lr=0.0001, optim_type='sgd', total_steps=35000, selectivity=0.2, in_dim=in_dim)
    os.killpg(os.getpgid(pro.pid), signal.SIGTERM)
    pw_avg, tr_time,engy=get_power_stats(path, stats_test_data_20['runtime'][0])
    if (n==0): #in the firts iteration we create the dictionnaries where we store data
        dico_global_data_select_20['energy']=engy
        dico_global_data_select_20['tr_time']=tr_time
        dico_global_data_select_20['pw_avg']=pw_avg
        dico_global_data_select_20['runtime']=stats_test_data_20['runtime'][0]
        dico_global_data_select_20['loss_curves']=np.array(stats_test_data_20['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_data_select_20['energy']+=engy
        dico_global_data_select_20['tr_time']+=tr_time
        dico_global_data_select_20['pw_avg']+=pw_avg
        dico_global_data_select_20['runtime']+=stats_test_data_20['runtime'][0]
        tmp=np.array(stats_test_data_20['loss_curves'][0])
        l=min(len(tmp), len(dico_global_data_select_20['loss_curves']))
        dico_global_data_select_20['loss_curves']=np.add(dico_global_data_select_20['loss_curves'][0:l], tmp[0:l])
        
    

    
    print("data select 0.2 for curve")
    stats_test_data_20_curve = run_experiments_data_select_curve(seed=seed,all_data=all_data, width=width, n_data=5000,batch_size=100, lr=0.0001, optim_type='sgd', total_steps=35000, selectivity=0.2, in_dim=in_dim)
    if (n==0): #in the firts iteration we create the dictionnaries where we store data
        dico_global_data_select_20_curve['runtime']=stats_test_data_20_curve['runtime'][0]
        dico_global_data_select_20_curve['loss_curves']=np.array(stats_test_data_20_curve['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_data_select_20_curve['runtime']+=stats_test_data_20_curve['runtime'][0]
        tmp=np.array(stats_test_data_20_curve['loss_curves'][0])
        dico_global_data_select_20_curve['loss_curves']=np.add(dico_global_data_select_20_curve['loss_curves'], tmp)

    
    print("data select 0.13 for curve")
    stats_test_data_13_curve = run_experiments_data_select_curve(seed=seed,all_data=all_data, width=width, n_data=5000,batch_size=100, lr=0.0001, optim_type='sgd', total_steps=35000, selectivity=0.13, in_dim=in_dim)
    if (n==0): #in the firts iteration we create the dictionnaries where we store data
        dico_global_data_select_13_curve['runtime']=stats_test_data_13_curve['runtime'][0]
        dico_global_data_select_13_curve['loss_curves']=np.array(stats_test_data_13_curve['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_data_select_13_curve['runtime']+=stats_test_data_13_curve['runtime'][0]
        tmp=np.array(stats_test_data_13_curve['loss_curves'][0])
        dico_global_data_select_13_curve['loss_curves']=np.add(dico_global_data_select_13_curve['loss_curves'], tmp)

    print("data select 0.15 for curve")
    stats_test_data_15_curve = run_experiments_data_select_curve(seed=seed,all_data=all_data, width=width, n_data=5000,batch_size=100, lr=0.0001, optim_type='sgd', total_steps=35000, selectivity=0.15, in_dim=in_dim)
    if (n==0): #in the firts iteration we create the dictionnaries where we store data
        dico_global_data_select_15_curve['runtime']=stats_test_data_15_curve['runtime'][0]
        dico_global_data_select_15_curve['loss_curves']=np.array(stats_test_data_15_curve['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_data_select_15_curve['runtime']+=stats_test_data_15_curve['runtime'][0]
        tmp=np.array(stats_test_data_15_curve['loss_curves'][0])
        dico_global_data_select_15_curve['loss_curves']=np.add(dico_global_data_select_15_curve['loss_curves'], tmp)

    print("data select 0.17 for curve")
    stats_test_data_17_curve = run_experiments_data_select_curve(seed=seed,all_data=all_data, width=width, n_data=5000,batch_size=100, lr=0.0001, optim_type='sgd', total_steps=35000, selectivity=0.17, in_dim=in_dim)
    if (n==0): #in the firts iteration we create the dictionnaries where we store data
        dico_global_data_select_17_curve['runtime']=stats_test_data_17_curve['runtime'][0]
        dico_global_data_select_17_curve['loss_curves']=np.array(stats_test_data_17_curve['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_data_select_17_curve['runtime']+=stats_test_data_17_curve['runtime'][0]
        tmp=np.array(stats_test_data_17_curve['loss_curves'][0])
        dico_global_data_select_17_curve['loss_curves']=np.add(dico_global_data_select_17_curve['loss_curves'], tmp)



    
    print("data select 50%")
    path='/Users/Anais/Desktop/test_ts/data_select_50_seed_'+str(seed)+'_test.txt'
    command='sudo powermetrics -i 1000 | grep "Combined Power" --line-buffered | awk \'{print $8 > "/Users/Anais/Desktop/test_ts/data_select_50_seed_'+str(seed)+'_test.txt"}\''
    pro = subprocess.Popen(command, shell=True, start_new_session=True)
    time.sleep(1)
    stats_test_data_50 = run_experiments_data_select(seed=seed,all_data=all_data, width=width, n_data=5000,batch_size=100, lr=0.0001, optim_type='sgd', total_steps=35000, selectivity=0.5, in_dim=in_dim)
    os.killpg(os.getpgid(pro.pid), signal.SIGTERM)
    pw_avg, tr_time,engy=get_power_stats(path, stats_test_data_50['runtime'][0])
    if (n==0): #in the firts iteration we create the dictionnaries where we store data
        dico_global_data_select_50['energy']=engy
        dico_global_data_select_50['tr_time']=tr_time
        dico_global_data_select_50['pw_avg']=pw_avg
        dico_global_data_select_50['runtime']=stats_test_data_50['runtime'][0]
        dico_global_data_select_50['loss_curves']=np.array(stats_test_data_50['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_data_select_50['energy']+=engy
        dico_global_data_select_50['tr_time']+=tr_time
        dico_global_data_select_50['pw_avg']+=pw_avg
        dico_global_data_select_50['runtime']+=stats_test_data_50['runtime'][0]
        tmp=np.array(stats_test_data_50['loss_curves'][0])
        l=min(len(tmp), len(dico_global_data_select_50['loss_curves']))
        dico_global_data_select_50['loss_curves']=np.add(dico_global_data_select_50['loss_curves'][0:l], tmp[0:l])
        

    



    print("data select 0.5 for curve")
    stats_test_data_50_curve = run_experiments_data_select_curve(seed=seed,all_data=all_data, width=width, n_data=5000,batch_size=100, lr=0.0001, optim_type='sgd', total_steps=35000, selectivity=0.5, in_dim=in_dim)
    if (n==0): #in the firts iteration we create the dictionnaries where we store data
        dico_global_data_select_50_curve['runtime']=stats_test_data_50_curve['runtime'][0]
        dico_global_data_select_50_curve['loss_curves']=np.array(stats_test_data_50_curve['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_data_select_50_curve['runtime']+=stats_test_data_50_curve['runtime'][0]
        tmp=np.array(stats_test_data_50_curve['loss_curves'][0])
        dico_global_data_select_50_curve['loss_curves']=np.add(dico_global_data_select_50_curve['loss_curves'], tmp)




    print("gradmax")
    path='/Users/Anais/Desktop/test_ts/gradmax_seed_'+str(seed)+'_test.txt'
    command='sudo powermetrics -i 1000 | grep "Combined Power" --line-buffered | awk \'{print $8 > "/Users/Anais/Desktop/test_ts/gradmax_seed_'+str(seed)+'_test.txt"}\''
    pro = subprocess.Popen(command, shell=True, start_new_session=True)
    time.sleep(1)
    ALL_METHODS = ['gradmax']
    stats_test_gradmax, all_data = run_experiments_growing(ALL_METHODS, 'growth_type', seed=seed, width=width, n_data=5000, 
                                  lr=0.0001, n_repeat=1, growth_interval=500, final_steps=1000, num_to_add=[5,4,3,2,0],
                                  optim_type='sgd', all_data=all_data, batch_size=100, in_dim=in_dim)
    os.killpg(os.getpgid(pro.pid), signal.SIGTERM)
    pw_avg, tr_time,engy=get_power_stats(path, stats_test_gradmax['gradmax']['runtime'][0])
    print("gradmax, seed", seed, pw_avg, tr_time,engy, stats_test_gradmax['gradmax']['runtime'],stats_test_gradmax['gradmax']['loss_curves'][0][0:10] )
    if (n==0): #in the first iteration we create the dictionnaries where we store data
        dico_global_gradmax['energy']=engy
        dico_global_gradmax['tr_time']=tr_time
        dico_global_gradmax['pw_avg']=pw_avg
        dico_global_gradmax['runtime']=stats_test_gradmax['gradmax']['runtime'][0]
        dico_global_gradmax['loss_curves']=np.array(stats_test_gradmax['gradmax']['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_gradmax['energy']+=engy
        dico_global_gradmax['tr_time']+=tr_time
        dico_global_gradmax['pw_avg']+=pw_avg
        dico_global_gradmax['runtime']+=stats_test_gradmax['gradmax']['runtime'][0]
        tmp=np.array(stats_test_gradmax['gradmax']['loss_curves'][0])
        dico_global_gradmax['loss_curves']=np.add(dico_global_gradmax['loss_curves'], tmp)
        



    print("baseline small")
    path='/Users/Anais/Desktop/test_ts/baseline_small_seed_'+str(seed)+'_test.txt'
    command='sudo powermetrics -i 1000 | grep "Combined Power" --line-buffered | awk \'{print $8 > "/Users/Anais/Desktop/test_ts/baseline_small_seed_'+str(seed)+'_test.txt"}\''
    pro = subprocess.Popen(command, shell=True, start_new_session=True)
    time.sleep(1)
    ALL_METHODS = ['baseline_small']
    stats_test_baseline_small, all_data = run_experiments_growing(ALL_METHODS, 'growth_type', seed=seed, width=width, n_data=5000, 
                                  lr=0.0001, n_repeat=1, growth_interval=500, final_steps=1000, num_to_add=[5,4,3,2,0],
                                  optim_type='sgd', all_data=all_data, batch_size=100, in_dim=in_dim)
    os.killpg(os.getpgid(pro.pid), signal.SIGTERM)
    pw_avg, tr_time,engy=get_power_stats(path, stats_test_baseline_small['baseline_small']['runtime'][0])
    if (n==0): #in the firts iteration we create the dictionnaries where we store data
        dico_global_baseline_small['energy']=engy
        dico_global_baseline_small['tr_time']=tr_time
        dico_global_baseline_small['pw_avg']=pw_avg
        dico_global_baseline_small['runtime']=stats_test_baseline_small['baseline_small']['runtime'][0]
        dico_global_baseline_small['loss_curves']=np.array(stats_test_baseline_small['baseline_small']['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_baseline_small['energy']+=engy
        dico_global_baseline_small['tr_time']+=tr_time
        dico_global_baseline_small['pw_avg']+=pw_avg
        dico_global_baseline_small['runtime']+=stats_test_baseline_small['baseline_small']['runtime'][0]
        tmp=np.array(stats_test_baseline_small['baseline_small']['loss_curves'][0])
        dico_global_baseline_small['loss_curves']=np.add(dico_global_baseline_small['loss_curves'], tmp)
        





    print("baseline_big")
    path='/Users/Anais/Desktop/test_ts/baseline_big_seed_'+str(seed)+'_test.txt'
    command='sudo powermetrics -i 1000 | grep "Combined Power" --line-buffered | awk \'{print $8 > "/Users/Anais/Desktop/test_ts/baseline_big_seed_'+str(seed)+'_test.txt"}\''

    pro = subprocess.Popen(command, shell=True, start_new_session=True)
    time.sleep(1)
    ALL_METHODS = ['baseline_big']
    stats_test_baseline_big, all_data = run_experiments_growing(ALL_METHODS, 'growth_type', seed=seed, width=width, n_data=5000, 
                                  lr=0.0001, n_repeat=1, growth_interval=500, final_steps=1000, num_to_add=[5,4,3,2,0],
                                  optim_type='sgd', all_data=all_data, batch_size=100, in_dim=in_dim)
    os.killpg(os.getpgid(pro.pid), signal.SIGTERM)
    pw_avg, tr_time,engy=get_power_stats(path, stats_test_baseline_big['baseline_big']['runtime'][0])
    if (n==0): #in the firts iteration we create the dictionnaries where we store data
        dico_global_baseline_big['energy']=engy
        dico_global_baseline_big['tr_time']=tr_time
        dico_global_baseline_big['pw_avg']=pw_avg
        dico_global_baseline_big['runtime']=stats_test_baseline_big['baseline_big']['runtime'][0]
        dico_global_baseline_big['loss_curves']=np.array(stats_test_baseline_big['baseline_big']['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_baseline_big['energy']+=engy
        dico_global_baseline_big['tr_time']+=tr_time
        dico_global_baseline_big['pw_avg']+=pw_avg
        dico_global_baseline_big['runtime']+=stats_test_baseline_big['baseline_big']['runtime'][0]
        tmp=np.array(stats_test_baseline_big['baseline_big']['loss_curves'][0])
        dico_global_baseline_big['loss_curves']=np.add(dico_global_baseline_big['loss_curves'], tmp)





    ALL_METHODS = ['erk_random']
    path='/Users/Anais/Desktop/test_ts/pruning_erk_seed_'+str(seed)+'_test.txt'
    command='sudo powermetrics -i 1000 | grep "Combined Power" --line-buffered | awk \'{print $8 > "/Users/Anais/Desktop/test_ts/pruning_erk_seed_'+str(seed)+'_test.txt"}\''

    pro = subprocess.Popen(command, shell=True, start_new_session=True)
    time.sleep(1)
    stats_test_pruning_erk = run_experiments_pruning(ALL_METHODS, 'pruning_type', seed=seed, pruning_density=0.5, width=width, 
                                                        n_data=5000, lr=0.0001, n_repeat=1, optim_type='sgd', total_steps=35000, 
                                                        student_width=[100, 80, 60, 40, 10], all_data=all_data, batch_size=100, in_dim=in_dim)
    os.killpg(os.getpgid(pro.pid), signal.SIGTERM)
    pw_avg, tr_time,engy=get_power_stats(path, stats_test_pruning_erk['erk_random']['runtime'][0])
    if (n==0): #in the firts iteration we create the dictionnaries where we store data
        dico_global_pruning_erk['energy']=engy
        dico_global_pruning_erk['tr_time']=tr_time
        dico_global_pruning_erk['pw_avg']=pw_avg
        dico_global_pruning_erk['runtime']=stats_test_pruning_erk['erk_random']['runtime'][0]
        dico_global_pruning_erk['loss_curves']=np.array(stats_test_pruning_erk['erk_random']['loss_curves'][0])
    else: #in other iterations we compute the sum so that we can obtain the mean after all executions
        dico_global_pruning_erk['energy']+=engy
        dico_global_pruning_erk['tr_time']+=tr_time
        dico_global_pruning_erk['pw_avg']+=pw_avg
        dico_global_pruning_erk['runtime']+=stats_test_pruning_erk['erk_random']['runtime'][0]
        tmp=np.array(stats_test_pruning_erk['erk_random']['loss_curves'][0])
        dico_global_pruning_erk['loss_curves']=np.add(dico_global_pruning_erk['loss_curves'], tmp)



#compute mean

dico_global_data_select_20['energy']/=nb_exec
dico_global_data_select_20['tr_time']/=nb_exec
dico_global_data_select_20['pw_avg']/=nb_exec
dico_global_data_select_20['runtime']/=nb_exec
dico_global_data_select_20['loss_curves']=dico_global_data_select_20['loss_curves']/nb_exec


dico_global_data_select_20_curve['runtime']/=nb_exec
dico_global_data_select_20_curve['loss_curves']=dico_global_data_select_20_curve['loss_curves']/nb_exec

dico_global_data_select_13_curve['runtime']/=nb_exec
dico_global_data_select_13_curve['loss_curves']=dico_global_data_select_13_curve['loss_curves']/nb_exec

dico_global_data_select_15_curve['runtime']/=nb_exec
dico_global_data_select_15_curve['loss_curves']=dico_global_data_select_15_curve['loss_curves']/nb_exec

dico_global_data_select_17_curve['runtime']/=nb_exec
dico_global_data_select_17_curve['loss_curves']=dico_global_data_select_17_curve['loss_curves']/nb_exec


dico_global_data_select_50['energy']/=nb_exec
dico_global_data_select_50['tr_time']/=nb_exec
dico_global_data_select_50['pw_avg']/=nb_exec
dico_global_data_select_50['runtime']/=nb_exec
dico_global_data_select_50['loss_curves']=dico_global_data_select_50['loss_curves']/nb_exec

dico_global_data_select_50_curve['runtime']/=nb_exec
dico_global_data_select_50_curve['loss_curves']=dico_global_data_select_50_curve['loss_curves']/nb_exec


dico_global_gradmax['energy']/=nb_exec
dico_global_gradmax['tr_time']/=nb_exec
dico_global_gradmax['pw_avg']/=nb_exec
dico_global_gradmax['runtime']/=nb_exec
dico_global_gradmax['loss_curves']=dico_global_gradmax['loss_curves']/nb_exec
print("gradmax", dico_global_gradmax)

dico_global_baseline_small['energy']/=nb_exec
dico_global_baseline_small['tr_time']/=nb_exec
dico_global_baseline_small['pw_avg']/=nb_exec
dico_global_baseline_small['runtime']/=nb_exec
dico_global_baseline_small['loss_curves']=dico_global_baseline_small['loss_curves']/nb_exec

dico_global_baseline_big['energy']/=nb_exec
dico_global_baseline_big['tr_time']/=nb_exec
dico_global_baseline_big['pw_avg']/=nb_exec
dico_global_baseline_big['runtime']/=nb_exec
dico_global_baseline_big['loss_curves']=dico_global_baseline_big['loss_curves']/nb_exec

dico_global_pruning_erk['energy']/=nb_exec
dico_global_pruning_erk['tr_time']/=nb_exec
dico_global_pruning_erk['pw_avg']/=nb_exec
dico_global_pruning_erk['runtime']/=nb_exec
dico_global_pruning_erk['loss_curves']=dico_global_pruning_erk['loss_curves']/nb_exec

#store results
with (open("dico_global_data_select_20.pkl", 'wb') as f):
    pickle.dump(dico_global_data_select_20, f)
    f.close()


with (open("dico_global_data_select_20_curve.pkl", 'wb') as f):
    pickle.dump(dico_global_data_select_20_curve, f)
    f.close()

with (open("dico_global_data_select_13_curve.pkl", 'wb') as f):
    pickle.dump(dico_global_data_select_13_curve, f)
    f.close()

with (open("dico_global_data_select_15_curve.pkl", 'wb') as f):
    pickle.dump(dico_global_data_select_15_curve, f)
    f.close()

with (open("dico_global_data_select_17_curve.pkl", 'wb') as f):
    pickle.dump(dico_global_data_select_17_curve, f)
    f.close()

with (open("dico_global_data_select_50.pkl", 'wb') as f):
    pickle.dump(dico_global_data_select_50, f)
    f.close()


with (open("dico_global_data_select_50_curve.pkl", 'wb') as f):
    pickle.dump(dico_global_data_select_50_curve, f)
    f.close()

with (open("dico_global_gradmax.pkl", 'wb') as f):
    pickle.dump(dico_global_gradmax, f)
    f.close()

with (open("dico_global_baseline_small.pkl", 'wb') as f):
    pickle.dump(dico_global_baseline_small, f)
    f.close()

with (open("dico_global_baseline_big.pkl", 'wb') as f):
    pickle.dump(dico_global_baseline_big, f)
    f.close()


with (open("dico_global_pruning_erk.pkl", 'wb') as f):
    pickle.dump(dico_global_pruning_erk, f)
    f.close()





    

